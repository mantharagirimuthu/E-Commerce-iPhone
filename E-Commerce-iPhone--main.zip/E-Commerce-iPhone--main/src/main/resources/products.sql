insert into products values(1,"The iPhone 11 is the smartphone with built-in ultra-wideband hardware, via its Apple U1 chip.The iPhone 11 has a 6.1 in (15.5 cm) IPS LCD","img/110","Apple iPhone 11 (64GB) - White",46999.00);

insert into products values(2,"The iPhone 11 pro is the smartphone with built-in ultra-wideband hardware, via its Apple U1 chip.The iPhone pro has a 5.8 in which have OLED displays.","img/111","Apple iPhone 11 Pro (64GB) Space Grey",79899.00);

insert into products values(3,"The iPhone 11 pro Max is the smartphone with built-in ultra-wideband hardware, via its Apple U1 chip.The iPhone pro has a 6.5 in which have OLED displays.","img/112","Apple iPhone 11 Pro Max (64GB) Gold",117100.00);

insert into products values(4,"The iPhone 12 mini display has rounded corners that follow a beautiful curved design, and these corners are within a standard rectangle.","img/120","Apple iPhone 12 mini (128GB) Purple",64900.00);

insert into products values(5,"The iPhone 12 display has rounded corners that follow a beautiful curved design, and these corners are within a standard rectangle.","img/121","Apple iPhone 12 (64GB) White",77900.00);

insert into products values(6,"The iPhone 12 Pro uses Apple's six-core A14 Bionic processor, which contains a 16-core neural enginehe iPhone 12 Pro has an IP68 water and dust-resistant rating along with dirt and grime","img/122","Apple iPhone 12 Pro (128GB) Pacific Blue",95900.00);

insert into products values(7,"Apple iPhone 13 has 128GB 6GB RAM, 256GB 6GB RAM, 512GB 6GB RAM of built-in memory.This device has a Apple A15 Bionic (5 nm) chipset.","img/130","Apple iPhone 13 (256GB) Midnight",89900.00);

insert into products values(8,"Apple iPhone 13 Pro has 1TB  8GB RAM,of built-in memory.This device has a Apple A15 Bionic (5 nm) chipset.The main screen size is 6.1 inches, 90.2 cm2 with 1170 x 2532 pixels, 19.5:9 ratio resolution.","img/131","Apple iPhone 13 Pro (1TB) Sierra Blue",169900.00);

insert into products values(9,"Apple iPhone 13 Pro has 128GB  8GB RAM,of built-in memory.This device has a Apple A15 Bionic (5 nm) chipset.The main screen size is 6.7-inch OLED; 2,778x1,284 pixels.It has a 458 ppi pixel density.","img/132","Apple iPhone 13 Pro Max (128GB) Sierra Blue",129900.00);

insert into products values(10,"The iPhone 13 Mini is the successor to Apple's first super mini flagship in recent years, the iPhone 12 Mini.It retains the same 5.4 inc screen size and the one-handed use friendly form factor","img/133","Apple iPhone 13 Mini (128GB) Pink",69900.00);

